<?php
require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['kursi'])) {
    header('Location: index.php');
    exit;
}

$trayek_id = (int)$_POST['trayek_id'];
$kursi_ids = array_map('intval', $_POST['kursi']);

$stmt = $pdo->prepare("SELECT * FROM trayek WHERE id = ?");
$stmt->execute([$trayek_id]);
$trayek = $stmt->fetch();
if (!$trayek) die('Trayek tidak ditemukan.');

$placeholders = implode(',', array_fill(0, count($kursi_ids), '?'));
$stmt = $pdo->prepare("SELECT * FROM kursi WHERE id IN ($placeholders) AND trayek_id = ?");
$stmt->execute([...$kursi_ids, $trayek_id]);
$kursi_list = $stmt->fetchAll();

// pastikan semua kursi yang diminta masih tersedia
$tidak_tersedia = array_filter($kursi_list, fn($k) => $k['status'] === 'terisi');
if (count($kursi_list) !== count($kursi_ids) || !empty($tidak_tersedia)) {
    die('Beberapa kursi yang kamu pilih sudah tidak tersedia. <a href="pilih_kursi.php?trayek_id=' . $trayek_id . '">Pilih ulang</a>');
}

$total_harga = $trayek['harga'] * count($kursi_list);
$kursi_ids_str = implode(',', $kursi_ids);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Isi Data Penumpang</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="container" style="padding-top:30px; display:flex; gap:30px; align-items:flex-start; flex-wrap:wrap;">
        <div style="flex:1; min-width:320px;">
            <h2 class="section-title" style="margin-top:0;">Data Penumpang</h2>

            <form action="proses_pesan.php" method="POST">
                <input type="hidden" name="trayek_id" value="<?= $trayek['id'] ?>">
                <input type="hidden" name="kursi_ids" value="<?= htmlspecialchars($kursi_ids_str) ?>">

                <?php foreach ($kursi_list as $i => $k): ?>
                    <div class="penumpang-block">
                        <div class="no-kursi">Kursi <?= htmlspecialchars($k['nomor_kursi']) ?></div>
                        <label>Nama Penumpang</label>
                        <input type="text" name="nama_penumpang[<?= $k['id'] ?>]" required>
                    </div>
                <?php endforeach; ?>

                <div class="card" style="margin-top:20px;">
                    <h3 style="font-size:16px; margin-bottom:6px;">Kontak Pemesan</h3>
                    <label>Email</label>
                    <input type="email" name="email" required>
                    <label>Nomor HP / WhatsApp</label>
                    <input type="text" name="no_hp" required>
                </div>

                <button type="submit" class="btn btn-block" style="margin-top:6px; padding:14px;">Konfirmasi &amp; Pesan Tiket</button>
            </form>
        </div>

        <div style="width:340px;">
            <div class="boarding-pass">
                <div class="top">
                    <div class="po"><?= htmlspecialchars($trayek['kelas']) ?></div>
                    <h3><?= htmlspecialchars($trayek['nama_po']) ?></h3>
                </div>
                <div class="body">
                    <div class="row"><span>Rute</span><span><?= htmlspecialchars($trayek['asal']) ?> → <?= htmlspecialchars($trayek['tujuan']) ?></span></div>
                    <div class="row"><span>Tanggal</span><span><?= formatTanggalIndo($trayek['tanggal_berangkat']) ?></span></div>
                    <div class="row"><span>Jam Berangkat</span><span><?= substr($trayek['jam_berangkat'],0,5) ?> WIB</span></div>
                    <div class="row"><span>Kursi</span><span><?= implode(', ', array_column($kursi_list, 'nomor_kursi')) ?></span></div>
                    <div class="row"><span>Jumlah Penumpang</span><span><?= count($kursi_list) ?> orang</span></div>
                    <div class="perforasi"></div>
                    <div class="row" style="font-size:16px;"><span>Total Bayar</span><span><?= formatRupiah($total_harga) ?></span></div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
