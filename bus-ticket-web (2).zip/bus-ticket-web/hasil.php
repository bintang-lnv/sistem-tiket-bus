<?php
require_once 'config/database.php';

$asal = trim($_GET['asal'] ?? '');
$tujuan = trim($_GET['tujuan'] ?? '');
$tanggal = trim($_GET['tanggal'] ?? date('Y-m-d'));

$stmt = $pdo->prepare("SELECT t.*, (SELECT COUNT(*) FROM kursi k WHERE k.trayek_id = t.id AND k.status='tersedia') as sisa_kursi
                        FROM trayek t
                        WHERE t.asal LIKE ? AND t.tujuan LIKE ? AND t.tanggal_berangkat = ?
                        ORDER BY t.jam_berangkat ASC");
$stmt->execute(["%$asal%", "%$tujuan%", $tanggal]);
$hasil = $stmt->fetchAll();

$kota = $pdo->query("SELECT DISTINCT asal FROM trayek UNION SELECT DISTINCT tujuan FROM trayek ORDER BY asal ASC")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hasil Pencarian — <?= htmlspecialchars($asal) ?> ke <?= htmlspecialchars($tujuan) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="hero" style="padding-bottom:40px;">
        <div class="hero-inner">
            <form class="search-panel" action="hasil.php" method="GET">
                <div class="field">
                    <label>Dari</label>
                    <input type="text" name="asal" list="daftar-kota" value="<?= htmlspecialchars($asal) ?>" required>
                </div>
                <div class="field">
                    <label>Ke</label>
                    <input type="text" name="tujuan" list="daftar-kota" value="<?= htmlspecialchars($tujuan) ?>" required>
                </div>
                <div class="field">
                    <label>Tanggal Berangkat</label>
                    <input type="date" name="tanggal" value="<?= htmlspecialchars($tanggal) ?>" required>
                </div>
                <button type="submit" class="btn">Cari Bus</button>
            </form>
            <datalist id="daftar-kota">
                <?php foreach ($kota as $k): ?>
                    <option value="<?= htmlspecialchars($k) ?>">
                <?php endforeach; ?>
            </datalist>
        </div>
    </div>

    <div class="container">
        <h2 class="section-title"><?= count($hasil) ?> bus ditemukan · <?= htmlspecialchars($asal) ?> → <?= htmlspecialchars($tujuan) ?> · <?= formatTanggalIndo($tanggal) ?></h2>

        <?php if (empty($hasil)): ?>
            <div class="empty-state">
                Tidak ada trayek yang cocok untuk pencarian ini.<br>
                Coba ubah kota atau tanggal keberangkatan.
            </div>
        <?php endif; ?>

        <?php foreach ($hasil as $t): ?>
            <div class="ticket-row">
                <div class="main">
                    <span class="kelas-tag"><?= htmlspecialchars($t['kelas']) ?></span>
                    <h3><?= htmlspecialchars($t['nama_po']) ?></h3>
                    <div class="rute">
                        <span class="kota"><?= substr($t['jam_berangkat'],0,5) ?></span>
                        <span class="garis"></span>
                        <span style="font-size:12px;"><?= $t['durasi_jam'] ?> jam</span>
                        <span class="garis"></span>
                        <span class="kota"><?= htmlspecialchars($t['asal']) ?> → <?= htmlspecialchars($t['tujuan']) ?></span>
                    </div>
                    <div class="fasilitas"><?= htmlspecialchars($t['fasilitas']) ?></div>
                </div>
                <div class="stub">
                    <div class="harga"><?= formatRupiah($t['harga']) ?><small>per kursi</small></div>
                    <div class="kursi-sisa"><?= $t['sisa_kursi'] ?> kursi tersisa</div>
                    <?php if ($t['sisa_kursi'] > 0): ?>
                        <a href="pilih_kursi.php?trayek_id=<?= $t['id'] ?>" class="btn btn-sm">Pilih Kursi</a>
                    <?php else: ?>
                        <button class="btn btn-sm" disabled>Kursi Habis</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
