<?php
require_once 'config/database.php';

$trayek_id = (int)($_GET['trayek_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM trayek WHERE id = ?");
$stmt->execute([$trayek_id]);
$trayek = $stmt->fetch();

if (!$trayek) {
    die('Trayek tidak ditemukan. <a href="index.php">Kembali ke beranda</a>');
}

$stmt = $pdo->prepare("SELECT * FROM kursi WHERE trayek_id = ? ORDER BY id ASC");
$stmt->execute([$trayek_id]);
$semua_kursi = $stmt->fetchAll();

// kelompokkan jadi baris berisi 4 kursi (2 - lorong - 2)
$baris = array_chunk($semua_kursi, 4);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pilih Kursi — <?= htmlspecialchars($trayek['nama_po']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="container" style="padding-top:30px;">
        <div class="card" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
            <div>
                <span class="kelas-tag"><?= htmlspecialchars($trayek['kelas']) ?></span>
                <h3 style="font-size:20px; margin-top:6px;"><?= htmlspecialchars($trayek['nama_po']) ?> — <?= htmlspecialchars($trayek['asal']) ?> → <?= htmlspecialchars($trayek['tujuan']) ?></h3>
                <p style="font-size:13px; color:var(--ink-soft); margin-top:4px;">
                    <?= formatTanggalIndo($trayek['tanggal_berangkat']) ?>, <?= substr($trayek['jam_berangkat'],0,5) ?> WIB · <?= $trayek['durasi_jam'] ?> jam perjalanan
                </p>
            </div>
            <div style="text-align:right;">
                <div class="harga" style="font-size:20px; font-family:'Big Shoulders Display',sans-serif; color:var(--navy-deep);"><?= formatRupiah($trayek['harga']) ?></div>
                <small style="color:var(--ink-soft);">per kursi</small>
            </div>
        </div>

        <h2 class="section-title" style="margin-top:24px;">Pilih Kursi</h2>

        <form id="form-kursi" action="checkout.php" method="POST">
            <input type="hidden" name="trayek_id" value="<?= $trayek['id'] ?>">

            <div class="seat-layout">
                <div class="kemudi">🚌 &nbsp; Depan (kemudi)</div>
                <?php foreach ($baris as $b): ?>
                    <div class="seat-row">
                        <div class="pair">
                            <?php foreach (array_slice($b, 0, 2) as $k): ?>
                                <?php $cls = $k['status'] === 'terisi' ? 'terisi' : 'tersedia'; ?>
                                <div class="seat <?= $cls ?>" data-id="<?= $k['id'] ?>" data-nomor="<?= htmlspecialchars($k['nomor_kursi']) ?>">
                                    <?= htmlspecialchars($k['nomor_kursi']) ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="aisle"></div>
                        <div class="pair">
                            <?php foreach (array_slice($b, 2, 2) as $k): ?>
                                <?php $cls = $k['status'] === 'terisi' ? 'terisi' : 'tersedia'; ?>
                                <div class="seat <?= $cls ?>" data-id="<?= $k['id'] ?>" data-nomor="<?= htmlspecialchars($k['nomor_kursi']) ?>">
                                    <?= htmlspecialchars($k['nomor_kursi']) ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="legend">
                    <div class="item"><span class="dot tersedia"></span> Tersedia</div>
                    <div class="item"><span class="dot selected"></span> Dipilih</div>
                    <div class="item"><span class="dot terisi"></span> Terisi</div>
                </div>
            </div>

            <div id="kursi-inputs"></div>

            <div class="sticky-bar">
                <div class="info">
                    <span id="jumlah-terpilih">0 kursi dipilih</span>
                    <strong id="total-harga">Rp0</strong>
                </div>
                <button type="submit" class="btn" id="btn-lanjut" disabled>Lanjut Isi Data</button>
            </div>
        </form>
    </div>

    <script>
        const harga = <?= (int)$trayek['harga'] ?>;
        const seats = document.querySelectorAll('.seat.tersedia');
        const inputsWrap = document.getElementById('kursi-inputs');
        const jumlahEl = document.getElementById('jumlah-terpilih');
        const totalEl = document.getElementById('total-harga');
        const btnLanjut = document.getElementById('btn-lanjut');
        let selected = [];

        function formatRupiah(n) {
            return 'Rp' + n.toLocaleString('id-ID');
        }

        function update() {
            jumlahEl.textContent = selected.length + ' kursi dipilih';
            totalEl.textContent = formatRupiah(selected.length * harga);
            btnLanjut.disabled = selected.length === 0;
            inputsWrap.innerHTML = '';
            selected.forEach(id => {
                const inp = document.createElement('input');
                inp.type = 'hidden';
                inp.name = 'kursi[]';
                inp.value = id;
                inputsWrap.appendChild(inp);
            });
        }

        seats.forEach(seat => {
            seat.addEventListener('click', () => {
                const id = seat.dataset.id;
                if (selected.includes(id)) {
                    selected = selected.filter(x => x !== id);
                    seat.classList.remove('selected');
                } else {
                    selected.push(id);
                    seat.classList.add('selected');
                }
                update();
            });
        });

        update();
    </script>
</body>
</html>
