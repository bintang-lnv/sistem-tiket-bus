<?php
require_once 'config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$trayek_id = (int)$_POST['trayek_id'];
$kursi_ids = array_map('intval', explode(',', $_POST['kursi_ids']));
$nama_penumpang_arr = $_POST['nama_penumpang'] ?? [];
$email = trim($_POST['email']);
$no_hp = trim($_POST['no_hp']);

$stmt = $pdo->prepare("SELECT * FROM trayek WHERE id = ?");
$stmt->execute([$trayek_id]);
$trayek = $stmt->fetch();
if (!$trayek) die('Trayek tidak ditemukan.');

$placeholders = implode(',', array_fill(0, count($kursi_ids), '?'));
$stmt = $pdo->prepare("SELECT * FROM kursi WHERE id IN ($placeholders) AND trayek_id = ? AND status = 'tersedia'");
$stmt->execute([...$kursi_ids, $trayek_id]);
$kursi_list = $stmt->fetchAll();

if (count($kursi_list) !== count($kursi_ids)) {
    die('Beberapa kursi sudah dipesan orang lain barusan. <a href="pilih_kursi.php?trayek_id=' . $trayek_id . '">Pilih ulang kursi</a>');
}

$total_harga = $trayek['harga'] * count($kursi_list);
$kode_booking = 'TB' . date('ymd') . strtoupper(substr(uniqid(), -5));

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("INSERT INTO bookings (kode_booking, trayek_id, nama_pemesan, email, no_hp, jumlah_kursi, total_harga, status)
                            VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
    $namaPemesan = reset($nama_penumpang_arr) ?: 'Penumpang';
    $stmt->execute([$kode_booking, $trayek_id, $namaPemesan, $email, $no_hp, count($kursi_list), $total_harga]);
    $booking_id = $pdo->lastInsertId();

    $stmtPenumpang = $pdo->prepare("INSERT INTO booking_penumpang (booking_id, kursi_id, nama_penumpang) VALUES (?, ?, ?)");
    $stmtKursi = $pdo->prepare("UPDATE kursi SET status = 'terisi' WHERE id = ?");

    foreach ($kursi_list as $k) {
        $nama = trim($nama_penumpang_arr[$k['id']] ?? 'Penumpang');
        $stmtPenumpang->execute([$booking_id, $k['id'], $nama]);
        $stmtKursi->execute([$k['id']]);
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    die('Gagal menyimpan pemesanan: ' . $e->getMessage());
}

header('Location: tiket.php?kode=' . urlencode($kode_booking));
exit;
