-- Import file ini lewat phpMyAdmin (XAMPP) atau lewat terminal:
-- mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS bus_ticket_db;
USE bus_ticket_db;

-- Tabel trayek (rute + jadwal bus)
CREATE TABLE IF NOT EXISTS trayek (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_po VARCHAR(100) NOT NULL,          -- nama perusahaan otobus, misal "Sinar Jaya"
    kelas VARCHAR(50) NOT NULL,             -- Ekonomi / Eksekutif / Super Eksekutif
    asal VARCHAR(100) NOT NULL,
    tujuan VARCHAR(100) NOT NULL,
    tanggal_berangkat DATE NOT NULL,
    jam_berangkat TIME NOT NULL,
    durasi_jam INT NOT NULL DEFAULT 0,      -- estimasi lama perjalanan (jam)
    harga DECIMAL(10,2) NOT NULL,
    total_kursi INT NOT NULL DEFAULT 40,
    fasilitas VARCHAR(255) DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel kursi per trayek
CREATE TABLE IF NOT EXISTS kursi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trayek_id INT NOT NULL,
    nomor_kursi VARCHAR(10) NOT NULL,
    status ENUM('tersedia','terisi') DEFAULT 'tersedia',
    FOREIGN KEY (trayek_id) REFERENCES trayek(id) ON DELETE CASCADE
);

-- Tabel pemesanan (satu pemesanan bisa berisi banyak kursi)
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_booking VARCHAR(20) UNIQUE NOT NULL,
    trayek_id INT NOT NULL,
    nama_pemesan VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    no_hp VARCHAR(20) NOT NULL,
    jumlah_kursi INT NOT NULL DEFAULT 1,
    total_harga DECIMAL(10,2) NOT NULL,
    status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trayek_id) REFERENCES trayek(id) ON DELETE CASCADE
);

-- Detail penumpang per kursi dalam satu pemesanan
CREATE TABLE IF NOT EXISTS booking_penumpang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    kursi_id INT NOT NULL,
    nama_penumpang VARCHAR(100) NOT NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (kursi_id) REFERENCES kursi(id) ON DELETE CASCADE
);

-- Tabel admin
CREATE TABLE IF NOT EXISTS admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Akun admin default -> username: admin | password: admin123
-- (GANTI setelah login pertama kali demi keamanan)
INSERT INTO admin (username, password) VALUES
('admin', '$2b$12$/1gckwbs.6spb2qJ1982Z.t9iFpSgyft0QozytsdfoG6eF.3pyWWC');

-- ============================================
-- Seed data: trayek bus + kursi (auto-generated)
-- ============================================

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Sinar Jaya', 'Eksekutif', 'Jakarta', 'Bandung', CURDATE() + INTERVAL 1 DAY, '08:00:00', 3, 95000, 32, 'AC, Reclining Seat, Bantal, Selimut');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Sinar Jaya', 'Ekonomi', 'Jakarta', 'Bandung', CURDATE() + INTERVAL 1 DAY, '13:00:00', 3, 65000, 40, 'AC, Kipas Tambahan');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D'), (@trayek_id, '9A'), (@trayek_id, '9B'), (@trayek_id, '9C'), (@trayek_id, '9D'), (@trayek_id, '10A'), (@trayek_id, '10B'), (@trayek_id, '10C'), (@trayek_id, '10D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Primajasa', 'Eksekutif', 'Jakarta', 'Yogyakarta', CURDATE() + INTERVAL 2 DAY, '19:00:00', 8, 240000, 32, 'AC, Reclining Seat, Bantal, Selimut, Colokan');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Kramat Djati', 'Super Eksekutif', 'Jakarta', 'Surabaya', CURDATE() + INTERVAL 3 DAY, '17:00:00', 14, 380000, 24, 'AC, Legrest, Toilet, Colokan, Snack');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Rosalia Indah', 'Eksekutif', 'Jakarta', 'Solo', CURDATE() + INTERVAL 2 DAY, '16:30:00', 9, 230000, 32, 'AC, Reclining Seat, Bantal, Selimut, Colokan');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Harapan Jaya', 'Ekonomi', 'Surabaya', 'Malang', CURDATE() + INTERVAL 1 DAY, '09:00:00', 3, 45000, 40, 'AC');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D'), (@trayek_id, '9A'), (@trayek_id, '9B'), (@trayek_id, '9C'), (@trayek_id, '9D'), (@trayek_id, '10A'), (@trayek_id, '10B'), (@trayek_id, '10C'), (@trayek_id, '10D');

INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas) VALUES
('Pahala Kencana', 'Eksekutif', 'Semarang', 'Jakarta', CURDATE() + INTERVAL 1 DAY, '20:00:00', 7, 210000, 32, 'AC, Reclining Seat, Bantal, Selimut');
SET @trayek_id = LAST_INSERT_ID();
INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (@trayek_id, '1A'), (@trayek_id, '1B'), (@trayek_id, '1C'), (@trayek_id, '1D'), (@trayek_id, '2A'), (@trayek_id, '2B'), (@trayek_id, '2C'), (@trayek_id, '2D'), (@trayek_id, '3A'), (@trayek_id, '3B'), (@trayek_id, '3C'), (@trayek_id, '3D'), (@trayek_id, '4A'), (@trayek_id, '4B'), (@trayek_id, '4C'), (@trayek_id, '4D'), (@trayek_id, '5A'), (@trayek_id, '5B'), (@trayek_id, '5C'), (@trayek_id, '5D'), (@trayek_id, '6A'), (@trayek_id, '6B'), (@trayek_id, '6C'), (@trayek_id, '6D'), (@trayek_id, '7A'), (@trayek_id, '7B'), (@trayek_id, '7C'), (@trayek_id, '7D'), (@trayek_id, '8A'), (@trayek_id, '8B'), (@trayek_id, '8C'), (@trayek_id, '8D');
