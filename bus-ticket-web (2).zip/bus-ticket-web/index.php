<?php
require_once 'config/database.php';

$kota = $pdo->query("SELECT DISTINCT asal FROM trayek UNION SELECT DISTINCT tujuan FROM trayek ORDER BY asal ASC")->fetchAll(PDO::FETCH_COLUMN);

// beberapa trayek untuk ditampilkan sebagai "rute populer"
$populer = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM kursi k WHERE k.trayek_id = t.id AND k.status='tersedia') as sisa_kursi
                         FROM trayek t WHERE t.tanggal_berangkat >= CURDATE() ORDER BY t.created_at DESC LIMIT 4")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TrayekBus — Pesan Tiket Bus Antar Kota</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="hero">
        <div class="hero-inner">
            <h1>Ke mana perjalanan<br>berikutnya?</h1>
            <p class="sub">Cari trayek, pilih kursi sendiri, pesan dalam hitungan menit.</p>

            <form class="search-panel" action="hasil.php" method="GET">
                <div class="field">
                    <label>Dari</label>
                    <input type="text" name="asal" list="daftar-kota" placeholder="Kota asal" required>
                </div>
                <div class="field">
                    <label>Ke</label>
                    <input type="text" name="tujuan" list="daftar-kota" placeholder="Kota tujuan" required>
                </div>
                <div class="field">
                    <label>Tanggal Berangkat</label>
                    <input type="date" name="tanggal" value="<?= date('Y-m-d') ?>" required>
                </div>
                <button type="submit" class="btn">Cari Bus</button>
            </form>
            <datalist id="daftar-kota">
                <?php foreach ($kota as $k): ?>
                    <option value="<?= htmlspecialchars($k) ?>">
                <?php endforeach; ?>
            </datalist>
        </div>
    </div>

    <div class="container">
        <h2 class="section-title">Trayek Terbaru</h2>

        <?php if (empty($populer)): ?>
            <div class="empty-state">Belum ada trayek tersedia. Coba lagi nanti.</div>
        <?php endif; ?>

        <?php foreach ($populer as $t): ?>
            <div class="ticket-row">
                <div class="main">
                    <span class="kelas-tag"><?= htmlspecialchars($t['kelas']) ?></span>
                    <h3><?= htmlspecialchars($t['nama_po']) ?></h3>
                    <div class="rute">
                        <span class="kota"><?= htmlspecialchars($t['asal']) ?></span>
                        <span class="garis"></span>
                        <span style="font-size:12px;"><?= $t['durasi_jam'] ?> jam</span>
                        <span class="garis"></span>
                        <span class="kota"><?= htmlspecialchars($t['tujuan']) ?></span>
                    </div>
                    <div class="fasilitas"><?= htmlspecialchars($t['fasilitas']) ?></div>
                </div>
                <div class="stub">
                    <div class="harga"><?= formatRupiah($t['harga']) ?><small>per kursi</small></div>
                    <div class="kursi-sisa"><?= $t['sisa_kursi'] ?> kursi tersisa · <?= formatTanggalIndo($t['tanggal_berangkat']) ?></div>
                    <a href="pilih_kursi.php?trayek_id=<?= $t['id'] ?>" class="btn btn-sm">Pilih Kursi</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
