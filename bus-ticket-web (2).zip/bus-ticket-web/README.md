# TrayekBus — Website Pemesanan Tiket Bus

Website pemesanan tiket bus antar kota bergaya web tiket sungguhan: cari trayek, pilih kursi di denah bus secara visual, isi data penumpang, dapat e-tiket. Dibuat pakai **PHP native + MySQL**, langsung jalan di XAMPP tanpa Composer.

## Alur Pengguna
1. **Beranda** — cari trayek berdasarkan kota asal, tujuan, dan tanggal
2. **Hasil pencarian** — daftar bus yang cocok, bergaya tiket (kelas, jam, fasilitas, harga)
3. **Pilih kursi** — denah bus visual (2 kursi - lorong - 2 kursi), klik kursi yang tersedia
4. **Isi data penumpang** — nama per kursi + kontak pemesan (email, HP)
5. **E-tiket** — kode booking + rincian perjalanan, bisa dicek ulang lewat menu "Cek Tiket"

## Fitur Admin (`/admin/login.php`)
- **Kelola Pemesanan** — lihat semua pemesanan, ubah status (pending/confirmed/cancelled — saat dibatalkan kursi otomatis dilepas lagi), hapus pemesanan, ringkasan pendapatan
- **Kelola Trayek** — tambah trayek baru (kursi ter-generate otomatis sesuai jumlah kursi yang diisi), hapus trayek

Login default: `admin` / `admin123` (ganti setelah testing)

## Cara Install (XAMPP)
1. Start **Apache** dan **MySQL** di XAMPP Control Panel
2. Copy folder `bus-ticket-web` ke `htdocs`
   - Windows: `C:\xampp\htdocs\bus-ticket-web`
   - Mac: `/Applications/XAMPP/htdocs/bus-ticket-web`
3. Buka `http://localhost/phpmyadmin`, tab **Import**, pilih `database.sql`, klik **Go**
   - Ini bikin database `bus_ticket_db`, semua tabel, akun admin, dan 7 contoh trayek lengkap dengan kursinya
4. Buka `http://localhost/bus-ticket-web/`

## Struktur Database
- `trayek` — jadwal & rute bus (PO, kelas, asal, tujuan, tanggal, jam, harga, fasilitas)
- `kursi` — nomor kursi per trayek + status (tersedia/terisi)
- `bookings` — data pemesanan (kode booking, pemesan, total harga, status)
- `booking_penumpang` — nama penumpang per kursi dalam satu pemesanan
- `admin` — akun login admin

## Struktur Folder
```
bus-ticket-web/
├── admin/
│   ├── login.php, auth.php, logout.php
│   ├── dashboard.php       (kelola pemesanan)
│   └── kelola_trayek.php   (kelola trayek + generate kursi)
├── assets/css/style.css
├── config/database.php
├── database.sql
├── index.php          (beranda + pencarian)
├── hasil.php          (hasil pencarian)
├── pilih_kursi.php    (denah kursi visual)
├── checkout.php       (form data penumpang)
├── proses_pesan.php   (simpan pemesanan)
├── tiket.php          (e-tiket)
└── cek_tiket.php      (cek status by kode booking)
```

## Upload ke GitHub
```bash
cd bus-ticket-web
git init
git add .
git commit -m "Website pemesanan tiket bus dengan pilih kursi dan admin panel"
git branch -M main
git remote add origin <url-repo-github-kamu>
git push -u origin main
```
Sebelum push: ganti password admin default di `database.sql`, dan jangan commit `config/database.php` versi produksi kalau kredensialnya bukan default XAMPP.
