<?php
// Konfigurasi koneksi database
// Sesuaikan jika username/password MySQL XAMPP kamu berbeda
$host = 'localhost';
$dbname = 'bus_ticket_db';
$dbuser = 'root';
$dbpass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $dbuser, $dbpass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage() . "<br>Pastikan MySQL di XAMPP sudah running dan database 'bus_ticket_db' sudah diimport (lihat database.sql).");
}

function formatRupiah($angka) {
    return 'Rp' . number_format($angka, 0, ',', '.');
}

function formatTanggalIndo($tanggal) {
    $bulan = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    $ts = strtotime($tanggal);
    return date('d', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
}
