<?php
require_once 'config/database.php';

$kode = trim($_GET['kode'] ?? '');

$stmt = $pdo->prepare("SELECT b.*, t.nama_po, t.kelas, t.asal, t.tujuan, t.tanggal_berangkat, t.jam_berangkat, t.durasi_jam
                        FROM bookings b JOIN trayek t ON b.trayek_id = t.id
                        WHERE b.kode_booking = ?");
$stmt->execute([$kode]);
$booking = $stmt->fetch();

if (!$booking) {
    die('Tiket tidak ditemukan. <a href="index.php">Kembali ke beranda</a>');
}

$stmt = $pdo->prepare("SELECT bp.nama_penumpang, k.nomor_kursi FROM booking_penumpang bp
                        JOIN kursi k ON bp.kursi_id = k.id WHERE bp.booking_id = ? ORDER BY k.nomor_kursi ASC");
$stmt->execute([$booking['id']]);
$penumpang = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>E-Tiket — <?= htmlspecialchars($booking['kode_booking']) ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="container" style="padding-top:30px; max-width:640px;">
        <div class="alert alert-success">Pemesanan berhasil! Tunjukkan e-tiket ini saat naik bus.</div>

        <div class="boarding-pass" style="max-width:100%;">
            <div class="top">
                <div class="po"><?= htmlspecialchars($booking['kelas']) ?></div>
                <h3><?= htmlspecialchars($booking['nama_po']) ?></h3>
            </div>
            <div class="body">
                <div class="row"><span>Rute</span><span><?= htmlspecialchars($booking['asal']) ?> → <?= htmlspecialchars($booking['tujuan']) ?></span></div>
                <div class="row"><span>Tanggal</span><span><?= formatTanggalIndo($booking['tanggal_berangkat']) ?></span></div>
                <div class="row"><span>Jam Berangkat</span><span><?= substr($booking['jam_berangkat'],0,5) ?> WIB</span></div>
                <div class="row"><span>Durasi</span><span>± <?= $booking['durasi_jam'] ?> jam</span></div>
                <div class="row"><span>Kursi</span><span><?= implode(', ', array_column($penumpang, 'nomor_kursi')) ?></span></div>
                <?php foreach ($penumpang as $p): ?>
                <div class="row"><span>Penumpang <?= htmlspecialchars($p['nomor_kursi']) ?></span><span><?= htmlspecialchars($p['nama_penumpang']) ?></span></div>
                <?php endforeach; ?>
                <div class="row"><span>Total Bayar</span><span><?= formatRupiah($booking['total_harga']) ?></span></div>
                <div class="row"><span>Status</span><span>
                    <?php $badgeClass = ['pending'=>'badge-pending','confirmed'=>'badge-confirmed','cancelled'=>'badge-cancelled']; ?>
                    <span class="badge <?= $badgeClass[$booking['status']] ?>"><?= $booking['status'] ?></span>
                </span></div>
                <div class="perforasi"></div>
            </div>
            <div class="kode">
                <div class="label">KODE BOOKING</div>
                <div class="value"><?= htmlspecialchars($booking['kode_booking']) ?></div>
            </div>
        </div>

        <?php if ($booking['status'] === 'pending'): ?>
        <p style="margin-top:16px; font-size:13px; color:var(--ink-soft);">
            Status tiket kamu masih <strong>pending</strong>, menunggu konfirmasi dari admin. Simpan kode booking untuk cek status kapan saja di halaman Cek Tiket.
        </p>
        <?php endif; ?>

        <a href="index.php" class="btn btn-outline" style="margin-top:20px;">Kembali ke Beranda</a>
    </div>
</body>
</html>
