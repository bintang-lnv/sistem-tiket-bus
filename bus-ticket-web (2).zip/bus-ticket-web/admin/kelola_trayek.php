<?php
require_once 'auth.php';
require_once '../config/database.php';

// Tambah trayek baru + generate kursi otomatis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['aksi'] ?? '') === 'tambah') {
    $total_kursi = max(4, (int)$_POST['total_kursi']);

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO trayek (nama_po, kelas, asal, tujuan, tanggal_berangkat, jam_berangkat, durasi_jam, harga, total_kursi, fasilitas)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        trim($_POST['nama_po']),
        trim($_POST['kelas']),
        trim($_POST['asal']),
        trim($_POST['tujuan']),
        $_POST['tanggal_berangkat'],
        $_POST['jam_berangkat'],
        (int)$_POST['durasi_jam'],
        (float)$_POST['harga'],
        $total_kursi,
        trim($_POST['fasilitas']),
    ]);
    $trayek_id = $pdo->lastInsertId();

    // generate nomor kursi: baris 4 kursi (2 - lorong - 2), misal 1A,1B,1C,1D,2A,...
    $stmtKursi = $pdo->prepare("INSERT INTO kursi (trayek_id, nomor_kursi) VALUES (?, ?)");
    $kolom = ['A', 'B', 'C', 'D'];
    $row = 1; $count = 0;
    while ($count < $total_kursi) {
        foreach ($kolom as $k) {
            if ($count >= $total_kursi) break;
            $stmtKursi->execute([$trayek_id, $row . $k]);
            $count++;
        }
        $row++;
    }
    $pdo->commit();
    header('Location: kelola_trayek.php');
    exit;
}

// Hapus trayek (kursi & booking terkait ikut terhapus via ON DELETE CASCADE)
if (isset($_GET['hapus'])) {
    $stmt = $pdo->prepare("DELETE FROM trayek WHERE id = ?");
    $stmt->execute([(int)$_GET['hapus']]);
    header('Location: kelola_trayek.php');
    exit;
}

$daftar = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM kursi k WHERE k.trayek_id = t.id AND k.status='tersedia') as sisa_kursi
                        FROM trayek t ORDER BY t.tanggal_berangkat ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Trayek — TrayekBus</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="dashboard.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="../index.php">Lihat Situs</a>
            <a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['admin_username']) ?>)</a>
        </nav>
    </div>

    <div class="admin-shell">
        <div class="admin-sidebar">
            <a href="dashboard.php">Pemesanan</a>
            <a href="kelola_trayek.php" class="active">Kelola Trayek</a>
        </div>

        <div class="admin-main">
            <div class="card">
                <h3 style="font-size:17px; margin-bottom:14px;">Tambah Trayek Baru</h3>
                <form method="POST">
                    <input type="hidden" name="aksi" value="tambah">
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:0 20px;">
                        <div>
                            <label>Nama PO Bus</label>
                            <input type="text" name="nama_po" placeholder="misal: Sinar Jaya" required>
                        </div>
                        <div>
                            <label>Kelas</label>
                            <select name="kelas" required>
                                <option value="Ekonomi">Ekonomi</option>
                                <option value="Eksekutif">Eksekutif</option>
                                <option value="Super Eksekutif">Super Eksekutif</option>
                            </select>
                        </div>
                        <div>
                            <label>Kota Asal</label>
                            <input type="text" name="asal" required>
                        </div>
                        <div>
                            <label>Kota Tujuan</label>
                            <input type="text" name="tujuan" required>
                        </div>
                        <div>
                            <label>Tanggal Berangkat</label>
                            <input type="date" name="tanggal_berangkat" required>
                        </div>
                        <div>
                            <label>Jam Berangkat</label>
                            <input type="time" name="jam_berangkat" required>
                        </div>
                        <div>
                            <label>Estimasi Durasi (jam)</label>
                            <input type="number" name="durasi_jam" min="1" value="3" required>
                        </div>
                        <div>
                            <label>Harga per Kursi (Rp)</label>
                            <input type="number" name="harga" min="0" required>
                        </div>
                        <div>
                            <label>Jumlah Kursi</label>
                            <input type="number" name="total_kursi" min="4" value="40" required>
                        </div>
                        <div>
                            <label>Fasilitas</label>
                            <input type="text" name="fasilitas" placeholder="AC, Reclining Seat, Bantal, Selimut">
                        </div>
                    </div>
                    <button type="submit" class="btn" style="margin-top:18px;">Tambah Trayek</button>
                </form>
            </div>

            <div class="card">
                <h3 style="font-size:17px; margin-bottom:14px;">Daftar Trayek</h3>
                <table>
                    <tr>
                        <th>PO</th><th>Kelas</th><th>Rute</th><th>Tanggal</th><th>Jam</th>
                        <th>Harga</th><th>Kursi Tersisa</th><th>Aksi</th>
                    </tr>
                    <?php foreach ($daftar as $t): ?>
                    <tr>
                        <td><?= htmlspecialchars($t['nama_po']) ?></td>
                        <td><?= htmlspecialchars($t['kelas']) ?></td>
                        <td><?= htmlspecialchars($t['asal']) ?> → <?= htmlspecialchars($t['tujuan']) ?></td>
                        <td><?= date('d/m/Y', strtotime($t['tanggal_berangkat'])) ?></td>
                        <td><?= substr($t['jam_berangkat'],0,5) ?></td>
                        <td><?= formatRupiah($t['harga']) ?></td>
                        <td><?= $t['sisa_kursi'] ?> / <?= $t['total_kursi'] ?></td>
                        <td><a href="?hapus=<?= $t['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus trayek ini? Semua kursi & pemesanan terkait ikut terhapus.')">Hapus</a></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($daftar)): ?>
                    <tr><td colspan="8" style="text-align:center; color:#888;">Belum ada trayek.</td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
