<?php
session_start();
require_once '../config/database.php';

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Admin — TrayekBus</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body style="background:var(--navy-deep); min-height:100vh; display:flex; align-items:center; justify-content:center;">
    <div style="width:100%; max-width:360px; padding:20px;">
        <div style="text-align:center; margin-bottom:20px;">
            <span class="brand" style="font-family:'Big Shoulders Display',sans-serif; font-size:30px; font-weight:800; color:#fff;">Trayek<span style="color:var(--amber);">Bus</span></span>
        </div>
        <div class="card" style="background:#fff;">
            <h2 style="font-size:20px; margin-bottom:4px;">Login Admin</h2>
            <p style="font-size:13px; color:var(--ink-soft);">Kelola trayek dan pemesanan tiket.</p>
            <?php if ($error): ?>
                <div class="alert alert-error" style="margin-top:14px;"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <label>Username</label>
                <input type="text" name="username" required>
                <label>Password</label>
                <input type="password" name="password" required>
                <button type="submit" class="btn btn-block" style="margin-top:18px;">Masuk</button>
            </form>
            <p style="margin-top:14px; font-size:12px; color:#999; text-align:center;">Default: admin / admin123</p>
        </div>
        <p style="text-align:center; margin-top:16px;"><a href="../index.php" style="color:#A9BACB; font-size:13px; text-decoration:none;">← Kembali ke situs</a></p>
    </div>
</body>
</html>
