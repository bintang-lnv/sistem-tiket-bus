<?php
require_once 'auth.php';
require_once '../config/database.php';

// Update status booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'], $_POST['status'])) {
    $booking_id = (int)$_POST['booking_id'];
    $status_baru = $_POST['status'];

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("UPDATE bookings SET status = ? WHERE id = ?");
    $stmt->execute([$status_baru, $booking_id]);

    // kalau dibatalkan, kembalikan kursi jadi tersedia lagi
    if ($status_baru === 'cancelled') {
        $stmt = $pdo->prepare("UPDATE kursi k JOIN booking_penumpang bp ON k.id = bp.kursi_id
                                SET k.status = 'tersedia' WHERE bp.booking_id = ?");
        $stmt->execute([$booking_id]);
    }
    $pdo->commit();
    header('Location: dashboard.php');
    exit;
}

// Hapus booking (kursi dilepas kembali)
if (isset($_GET['hapus'])) {
    $booking_id = (int)$_GET['hapus'];
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("UPDATE kursi k JOIN booking_penumpang bp ON k.id = bp.kursi_id
                            SET k.status = 'tersedia' WHERE bp.booking_id = ?");
    $stmt->execute([$booking_id]);
    $stmt = $pdo->prepare("DELETE FROM bookings WHERE id = ?");
    $stmt->execute([$booking_id]);
    $pdo->commit();
    header('Location: dashboard.php');
    exit;
}

$bookings = $pdo->query("SELECT b.*, t.nama_po, t.asal, t.tujuan, t.tanggal_berangkat
                          FROM bookings b JOIN trayek t ON b.trayek_id = t.id
                          ORDER BY b.created_at DESC")->fetchAll();

$totalPendapatan = $pdo->query("SELECT SUM(total_harga) as total FROM bookings WHERE status = 'confirmed'")->fetch()['total'] ?? 0;
$totalBooking = count($bookings);
$totalPending = count(array_filter($bookings, fn($b) => $b['status'] === 'pending'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin — TrayekBus</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="dashboard.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="../index.php">Lihat Situs</a>
            <a href="logout.php">Logout (<?= htmlspecialchars($_SESSION['admin_username']) ?>)</a>
        </nav>
    </div>

    <div class="admin-shell">
        <div class="admin-sidebar">
            <a href="dashboard.php" class="active">Pemesanan</a>
            <a href="kelola_trayek.php">Kelola Trayek</a>
        </div>

        <div class="admin-main">
            <div class="stat-grid">
                <div class="stat-card"><div class="label">Total Pemesanan</div><div class="value"><?= $totalBooking ?></div></div>
                <div class="stat-card"><div class="label">Menunggu Konfirmasi</div><div class="value"><?= $totalPending ?></div></div>
                <div class="stat-card"><div class="label">Pendapatan (confirmed)</div><div class="value"><?= formatRupiah($totalPendapatan) ?></div></div>
            </div>

            <div class="card">
                <h3 style="font-size:17px; margin-bottom:14px;">Data Pemesanan</h3>
                <table>
                    <tr>
                        <th>Kode</th><th>Pemesan</th><th>Trayek</th><th>Tanggal</th>
                        <th>Kursi</th><th>Total</th><th>Status</th><th>Aksi</th>
                    </tr>
                    <?php foreach ($bookings as $b): ?>
                    <tr>
                        <td><?= htmlspecialchars($b['kode_booking']) ?></td>
                        <td><?= htmlspecialchars($b['nama_pemesan']) ?><br><small style="color:#888;"><?= htmlspecialchars($b['email']) ?></small></td>
                        <td><?= htmlspecialchars($b['nama_po']) ?><br><small style="color:#888;"><?= htmlspecialchars($b['asal']) ?> → <?= htmlspecialchars($b['tujuan']) ?></small></td>
                        <td><?= date('d/m/Y', strtotime($b['tanggal_berangkat'])) ?></td>
                        <td><?= $b['jumlah_kursi'] ?></td>
                        <td><?= formatRupiah($b['total_harga']) ?></td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="pending" <?= $b['status']==='pending'?'selected':'' ?>>pending</option>
                                    <option value="confirmed" <?= $b['status']==='confirmed'?'selected':'' ?>>confirmed</option>
                                    <option value="cancelled" <?= $b['status']==='cancelled'?'selected':'' ?>>cancelled</option>
                                </select>
                            </form>
                        </td>
                        <td>
                            <a href="?hapus=<?= $b['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus pemesanan ini? Kursi akan dikembalikan jadi tersedia.')">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($bookings)): ?>
                    <tr><td colspan="8" style="text-align:center; color:#888;">Belum ada data pemesanan.</td></tr>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
