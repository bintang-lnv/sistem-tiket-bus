<?php
require_once 'config/database.php';

$booking = null;
$penumpang = [];
$notfound = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode = trim($_POST['kode_booking']);
    $stmt = $pdo->prepare("SELECT b.*, t.nama_po, t.kelas, t.asal, t.tujuan, t.tanggal_berangkat, t.jam_berangkat, t.durasi_jam
                            FROM bookings b JOIN trayek t ON b.trayek_id = t.id
                            WHERE b.kode_booking = ?");
    $stmt->execute([$kode]);
    $booking = $stmt->fetch();

    if ($booking) {
        $stmt = $pdo->prepare("SELECT bp.nama_penumpang, k.nomor_kursi FROM booking_penumpang bp
                                JOIN kursi k ON bp.kursi_id = k.id WHERE bp.booking_id = ? ORDER BY k.nomor_kursi ASC");
        $stmt->execute([$booking['id']]);
        $penumpang = $stmt->fetchAll();
    } else {
        $notfound = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cek Tiket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="topbar">
        <a href="index.php" class="brand">Trayek<span class="accent">Bus</span></a>
        <nav>
            <a href="cek_tiket.php">Cek Tiket</a>
            <a href="admin/login.php">Admin</a>
        </nav>
    </div>

    <div class="container" style="padding-top:30px; max-width:520px;">
        <h2 class="section-title" style="margin-top:0;">Cek Status Tiket</h2>
        <div class="card">
            <form method="POST">
                <label>Kode Booking</label>
                <input type="text" name="kode_booking" placeholder="Contoh: TB2609XXXXX" required
                       value="<?= isset($_POST['kode_booking']) ? htmlspecialchars($_POST['kode_booking']) : '' ?>">
                <button type="submit" class="btn btn-block" style="margin-top:16px;">Cek Status</button>
            </form>
        </div>

        <?php if ($notfound): ?>
            <div class="alert alert-error">Kode booking tidak ditemukan. Periksa kembali kode yang kamu masukkan.</div>
        <?php endif; ?>

        <?php if ($booking): ?>
            <div class="boarding-pass" style="max-width:100%;">
                <div class="top">
                    <div class="po"><?= htmlspecialchars($booking['kelas']) ?></div>
                    <h3><?= htmlspecialchars($booking['nama_po']) ?></h3>
                </div>
                <div class="body">
                    <div class="row"><span>Rute</span><span><?= htmlspecialchars($booking['asal']) ?> → <?= htmlspecialchars($booking['tujuan']) ?></span></div>
                    <div class="row"><span>Tanggal</span><span><?= formatTanggalIndo($booking['tanggal_berangkat']) ?></span></div>
                    <div class="row"><span>Jam Berangkat</span><span><?= substr($booking['jam_berangkat'],0,5) ?> WIB</span></div>
                    <div class="row"><span>Kursi</span><span><?= implode(', ', array_column($penumpang, 'nomor_kursi')) ?></span></div>
                    <div class="row"><span>Total Bayar</span><span><?= formatRupiah($booking['total_harga']) ?></span></div>
                    <div class="row"><span>Status</span><span>
                        <?php $badgeClass = ['pending'=>'badge-pending','confirmed'=>'badge-confirmed','cancelled'=>'badge-cancelled']; ?>
                        <span class="badge <?= $badgeClass[$booking['status']] ?>"><?= $booking['status'] ?></span>
                    </span></div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
